scheduler_events = {
    "cron": {
        "45 9 * * *": ["customization.scripts.checkin_report.execute"]
    }
}

fixtures = ["Scheduled Job Type"]
